*******************************************************************************
****** Cmos_buffer schematic bi_To_Gr  <vs>  Cmos_buffer layout bi_To_Gr
*******************************************************************************

Filter/Reduce statistics only. Network matching was OK.
                                                                                                                                                                   
Pre-expand Statistics                      
======================                          Original       
Cell/Device                               schematic  layout
(g45n1svt) MOS                                    2       2
(g45p1svt) MOS                                    2       2
                                             ------  ------
Total                                             4       4

Reduce Statistics
=================                               Original             Reduced
Cell/Device                               schematic  layout   schematic  layout
(g45n1svt) MOS                                    2       2           2       2
(g45p1svt) MOS                                    2       2           2       2
                                             ------  ------      ------  ------
Total                                             4       4           4       4

Schematic and Layout Match
